#include <iostream>

using namespace std;

int main()
{
    /* code */
    float b, h, a;
    cout << "PROGRAMA PARA LA AREA DEL PARALELOGRAMO" << endl << endl;
    cout << "Digite la base" << endl;
    cin >> b;
    cout << "Digite la altura" << endl;
    cin >> h;
    system("cls");
    a = b * h;
    cout << "El area del paralelogramo es " << a << endl;
    system("pause");
    return EXIT_SUCCESS;
}

/* Nelson Andres Delgado Machado */