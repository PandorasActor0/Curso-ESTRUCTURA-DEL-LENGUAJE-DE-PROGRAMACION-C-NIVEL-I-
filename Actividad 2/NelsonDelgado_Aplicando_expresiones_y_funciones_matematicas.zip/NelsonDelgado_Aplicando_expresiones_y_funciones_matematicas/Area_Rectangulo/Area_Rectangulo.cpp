#include <iostream>

using namespace std;

int main()
{
    /* code */
    float a, b, c;
    cout << "PROGRAMA PARA EL AREA DEL RECTANGULO " << endl << endl;
    cout << "Digite el ancho del rectangulo " << endl;
    cin >> a;
    cout << "Digite el largo del rectangulo " << endl;
    cin >> b;

    system("CLS");
    c = a * b;
    cout << "El area del rectangulo es " << c << endl;
    system("pause");

    return EXIT_SUCCESS;
}
/* Nelson Andres Delgado Machado */